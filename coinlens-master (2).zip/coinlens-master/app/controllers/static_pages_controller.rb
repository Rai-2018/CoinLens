class StaticPagesController < ApplicationController
  def home
  end

  def about
  end

  def features
  end

  def register
  end

  def login
  end

  def contact
  end
end
