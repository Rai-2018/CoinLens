class CoinsController < ApplicationController
end
