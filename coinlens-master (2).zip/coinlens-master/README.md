# COINLENS APPLICATION

Currently deployed via Heroku @ https://coinlens.herokuapp.com/

Build version: 0.1  
Ruby version: 2.5.1  
Rails version: 5.2.1  
Database: MySQL via ClearDB

Coinlens is a cryptocurrency investment portfolio tracker deployed as a web application. Development for this project is on-going.
